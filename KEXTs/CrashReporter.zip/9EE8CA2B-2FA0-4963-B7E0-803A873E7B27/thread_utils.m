//
// thread_utils.m
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#import "thread_utils.h"

static inline NSDictionary *frame_for_pc(uint64_t addr, NSArray *usedImages)
{
	for(NSUInteger i = 0; i < usedImages.count; i++)
	{
		NSDictionary *img = usedImages[i];
		uint64_t base = [img[@"base"] unsignedLongLongValue];
		uint64_t size = [img[@"size"] unsignedLongLongValue];
		if(size == 0)
		{
			continue;
		}
		if(addr >= base && addr < base + size)
		{
			return @{ @"imageOffset": @(addr - base), @"imageIndex": @(i) };
		}
	}
	return @{ @"imageOffset": @(addr), @"imageIndex": @(-1) };
}

NSDictionary *thread_state_dict(const arm_thread_state64_t *ts)
{
	NSMutableArray *xs = [NSMutableArray arrayWithCapacity:29];
	for(int i = 0; i < 29; i++)
	{
		[xs addObject:@{ @"value": @(ts->__x[i]) }];
	}
	
	return @{
		@"flavor": @"ARM_THREAD_STATE64",
		@"x": xs,
		@"lr": @{ @"value": @(arm_thread_state64_get_lr(*ts)) },
		@"fp": @{ @"value": @(arm_thread_state64_get_fp(*ts)) },
		@"sp": @{ @"value": @(arm_thread_state64_get_sp(*ts)) },
		@"pc": @{ @"value": @(arm_thread_state64_get_pc(*ts)) },
		@"cpsr": @{ @"value": @(ts->__cpsr) },
		@"far": @{ @"value": @(0) }, /* TODO: fill from exc code[1] for the faulting thread */
	};
}

NSArray *backtrace_for_thread(task_t task, const arm_thread_state64_t *ts, NSArray *usedImages)
{
	NSMutableArray *frames = [NSMutableArray array];
	
	uint64_t pc = arm_thread_state64_get_pc(*ts);
	uint64_t fp = arm_thread_state64_get_fp(*ts);
	
	if(pc)
	{
		[frames addObject:frame_for_pc(pc, usedImages)];
	}
	
	const int MAX_FRAMES = 128;
	const uint64_t MAX_FP_JUMP = 16 * 1024 * 1024;
	
	uint64_t seen[MAX_FRAMES];
	int seen_count = 0;
	
	for(int i = 0; i < MAX_FRAMES && fp; i++)
	{
		if(fp & 0xf)
		{
			break;
		}
		
		struct { uint64_t saved_fp, saved_lr; } f;
		vm_size_t got = 0;
		if(vm_read_overwrite(task, (vm_address_t)fp, sizeof f, (vm_address_t)&f, &got) != KERN_SUCCESS || got != sizeof f)
		{
			break;
		}
		uint64_t ret = f.saved_lr & 0x0000007fffffffffull; /* strip PAC */
		if(!ret)
		{
			break;
		}
		[frames addObject:frame_for_pc(ret, usedImages)];
		
		uint64_t next_fp = f.saved_fp & 0x0000007fffffffffull; /* strip PAC */
		
		if(next_fp <= fp)
		{
			break;
		}
		if(next_fp - fp > MAX_FP_JUMP)
		{
			break;
		}
		
		bool cycle = false;
		for(int j = 0; j < seen_count; j++)
		{
			if(seen[j] == next_fp)
			{
				cycle = true;
				break;
			}
		}
		if(cycle)
		{
			break;
		}
		seen[seen_count++] = next_fp;
		
		fp = next_fp;
	}
	return frames;
}
