//
// vm_summary.h
// CrashReporter
//
// Created by Anonym on 01.09.26.
//

#ifndef VM_SUMMARY_H
#define VM_SUMMARY_H

#import <Foundation/Foundation.h>

NSString *vm_summary_for_task(task_t task);

#endif /* VM_SUMMARY_H */
