//
// helper.m
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#import "helper.h"
#import <LindChain/ProcEnvironment/Surface/surface.h>

@implementation NSString (PECrashreporter)

- (BOOL)isEmpty
{
	if(((NSNull *) self == [NSNull null]) || (self == nil))
	{
		return YES;
	}
	typeof(self) copySelf = [self stringByTrimmingCharactersInSet: [NSCharacterSet whitespaceAndNewlineCharacterSet]];
	if([copySelf isEqualToString:@""])
	{
		return YES;
	}
	return NO;  
}

@end

NSString *make_timestamp(NSDate *date)
{
	static NSDateFormatter *fmt;
	static dispatch_once_t once;
	dispatch_once(&once, ^{
		fmt = [[NSDateFormatter alloc] init];
		fmt.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
		fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss.SS Z";
	});
	return [fmt stringForObjectValue:date];
}

NSString *model_code(void)
{
	size_t len = 0;
	sysctlbyname("hw.machine", NULL, &len, NULL, 0);
	if(len == 0)
	{
		return @"unknown";
	}
	
	char *buf = malloc(len);
	if(sysctlbyname("hw.machine", buf, &len, NULL, 0) != 0)
	{
		free(buf);
		return @"unknown";
	}
	NSString *s = [NSString stringWithUTF8String:buf];
	free(buf);
	return s;
}

NSString *crash_reporter_key(void)
{
	unsigned char digest[CC_SHA1_DIGEST_LENGTH];
	CC_SHA1(ksurface->pub_key, (CC_LONG)ksurface->pub_key_len, digest);
	
	NSMutableString *hex = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
	for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++)
	{
		[hex appendFormat:@"%02x", digest[i]];
	}
	return hex;
}

ssize_t write_all(int fd, const void *buf, size_t len)
{
	const uint8_t *p = buf; size_t off = 0;
	while(off < len)
	{
		ssize_t n = write(fd, p + off, len - off);
		if(n < 0)
		{
			if(errno == EINTR)
			{
				continue;
			}
			return -1;
		}
		off += (size_t)n;
	}
	return (ssize_t)off;
}
