//
// exc_utils.m
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#import "exc_utils.h"

const char *exc_type_name(exception_type_t t)
{
	switch(t)
	{
		case EXC_BAD_ACCESS: return "EXC_BAD_ACCESS";
		case EXC_BAD_INSTRUCTION: return "EXC_BAD_INSTRUCTION";
		case EXC_ARITHMETIC: return "EXC_ARITHMETIC";
		case EXC_EMULATION: return "EXC_EMULATION";
		case EXC_SOFTWARE: return "EXC_SOFTWARE";
		case EXC_BREAKPOINT: return "EXC_BREAKPOINT";
		case EXC_SYSCALL: return "EXC_SYSCALL";
		case EXC_MACH_SYSCALL: return "EXC_MACH_SYSCALL";
		case EXC_RPC_ALERT: return "EXC_RPC_ALERT";
		case EXC_CRASH: return "EXC_CRASH";
		case EXC_RESOURCE: return "EXC_RESOURCE";
		case EXC_GUARD: return "EXC_GUARD";
		case EXC_CORPSE_NOTIFY: return "EXC_CORPSE_NOTIFY";
		default: return "EXC_UNKNOWN";
	}
}

static inline const char *signal_name(int sig)
{
	switch (sig)
	{
		case SIGHUP: return "SIGHUP";
		case SIGINT: return "SIGINT";
		case SIGQUIT: return "SIGQUIT";
		case SIGILL: return "SIGILL";
		case SIGTRAP: return "SIGTRAP";
		case SIGABRT: return "SIGABRT";
		case SIGEMT: return "SIGEMT";
		case SIGFPE: return "SIGFPE";
		case SIGKILL: return "SIGKILL";
		case SIGBUS: return "SIGBUS";
		case SIGSEGV: return "SIGSEGV";\
		case SIGSYS: return "SIGSYS";
		case SIGPIPE: return "SIGPIPE";
		case SIGALRM: return "SIGALRM";
		case SIGTERM: return "SIGTERM";
		default: return "UNKNOWN";
	}
}

const char *exc_signal_name(exception_type_t exc, int64_t code0)
{
	switch(exc)
	{
		case EXC_BAD_ACCESS:
			if(code0 == KERN_INVALID_ADDRESS || code0 == KERN_PROTECTION_FAILURE)
			{
				return "SIGSEGV";
			}
			return "SIGBUS";
		case EXC_BAD_INSTRUCTION:
			return "SIGILL";
		case EXC_ARITHMETIC:
			return "SIGFPE";
		case EXC_EMULATION:
			return "SIGEMT";
		case EXC_SOFTWARE:
			return "SIGSYS";
		case EXC_BREAKPOINT:
			return "SIGTRAP";
		case EXC_SYSCALL:
			return "SIGSYS";
		case EXC_CRASH:
		{
			/* when EXC_CRASH happens code0 carries the UNIX signal */
			int sig = (int)(((uint64_t)code0 >> 24) & 0xff);
			return signal_name(sig);
		}
		case EXC_GUARD:
		case EXC_RESOURCE:
			return "SIGKILL";
		default:
			return "UNKNOWN";
	}
}
