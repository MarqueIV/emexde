//
// thread_utils.h
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#ifndef THREAD_UTILS_H
#define THREAD_UTILS_H

@import Foundation;
@import Darwin;

NSDictionary *thread_state_dict(const arm_thread_state64_t *ts);
NSArray *backtrace_for_thread(task_t task, const arm_thread_state64_t *ts, NSArray *usedImages);

#endif /* THREAD_UTILS_H */
