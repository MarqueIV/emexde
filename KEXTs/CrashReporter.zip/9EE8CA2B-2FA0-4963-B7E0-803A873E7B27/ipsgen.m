//
// ipsgen.m
// CrashReporter
//
// Created by mach-port-t on 02.09.26.
//

#import <LindChain/ProcEnvironment/Surface/sys/syscall.h>
#import <LindChain/ProcEnvironment/Utils/klog.h>
#import <LindChain/ProcEnvironment/Surface/proc/lookup.h>
#import <LindChain/ProcEnvironment/PEProcessManager.h>
#import <LindChain/ProcEnvironment/Surface/kxld/image.h>
#import <ksurface_abi.h>
#import "handoffep+crashreporter.h"
#import "vm_summary.h"
#import "image_utils.h"
#import "thread_utils.h"
#import "exc_utils.h"
#import "helper.h"
#import "ipsgen.h"

extern const kinfo_mod_t ksurface_kext_info;

void generateIPS(task_t task, thread_t thread, exception_type_t exc_type, mach_msg_type_number_t code_count, integer_t code[2], NSUUID *bootSessionUUID)
{
	pid_t pid;
	kern_return_t kr = pid_for_task(task, &pid);
	if(kr != KERN_SUCCESS)
	{
		klog_log("org.emexlabs.CrashReporter", "failed to get pid from task port %d", task);
		return;
	}
	klog_log("org.emexlabs.CrashReporter", "pid is %d", pid);
	
	/* getting process name */
	ksurface_proc_t *proc;
	kr = proc_for_pid(pid, &proc);
	if(kr != KERN_SUCCESS)
	{
		klog_log("org.emexlabs.CrashReporter", "failed to get proc");
		return;
	}
	klog_log("org.emexlabs.CrashReporter", "proc is @ %p", proc);
	
	/* now we access the process and copy its intel out ^^ */
	kvo_rdlock(&proc);
	klog_log("org.emexlabs.CrashReporter", "proc name is '%s'", proc->bsd.kp_proc.p_comm);
	
	CFDateFormatterRef fmt = CFDateFormatterCreate(NULL, NULL, kCFDateFormatterNoStyle, kCFDateFormatterNoStyle);
	CFDateFormatterSetFormat(fmt, CFSTR("yyyy-MM-dd-HHmmss"));
	
	CFStringRef stamp = CFDateFormatterCreateStringWithAbsoluteTime(NULL, fmt, CFAbsoluteTimeGetCurrent());
	CFStringRef path;
	
	if(proc->bsd.kp_proc.p_flag & P_SYSTEM)
	{
		path = CFStringCreateWithFormat(NULL, NULL, CFSTR("%s/Documents/rootfs/var/crashreporter/panic-full-%@.ips"), getenv("HOME"), stamp);
	}
	else
	{
		path = CFStringCreateWithFormat(NULL, NULL, CFSTR("%s/Documents/rootfs/var/crashreporter/%s-%@.ips"), getenv("HOME"), proc->bsd.kp_proc.p_comm, stamp);
	}
	
	CFRelease(fmt);
	CFRelease(stamp);
	
	const char *cPath = CFStringGetCStringPtr(path, kCFStringEncodingUTF8);
	klog_log("org.emexlabs.CrashReporter", "ips path would be '%s'", cPath);
	
	int fd = open(cPath, O_RDWR | O_CREAT | O_TRUNC, 0666);
	@autoreleasepool
	{
		NSDictionary *sharedCache = nil;
		NSArray *usedImages = used_images_for_task(task, &sharedCache);
		
		thread_act_array_t thread_list;
		mach_msg_type_number_t thread_count;
		task_threads(task, &thread_list, &thread_count);
		
		mach_port_t crashed = thread;
		int faulting_index = -1;
		
		NSMutableArray *threadsArray = [NSMutableArray array];
		
		for(mach_msg_type_number_t i = 0; i < thread_count; i++)
		{
			NSMutableDictionary *td = [NSMutableDictionary dictionary];
			
			BOOL isCrashed = (thread_list[i] == crashed);
			if(isCrashed)
			{
				faulting_index = (int)i;
				td[@"triggered"] = @(YES);
			}
			
			thread_identifier_info_data_t tid;
			mach_msg_type_number_t tcnt = THREAD_IDENTIFIER_INFO_COUNT;
			if(thread_info(thread_list[i], THREAD_IDENTIFIER_INFO, (thread_info_t)&tid, &tcnt) == KERN_SUCCESS)
			{
				td[@"id"] = @(tid.thread_id);
			}
			
			arm_thread_state64_t ts;
			mach_msg_type_number_t scnt = ARM_THREAD_STATE64_COUNT;
			if(thread_get_state(thread_list[i], ARM_THREAD_STATE64, (thread_state_t)&ts, &scnt) == KERN_SUCCESS)
			{
				NSMutableDictionary *stateDict = [thread_state_dict(&ts) mutableCopy];
				if(isCrashed)
				{
					NSMutableDictionary *pcd = [stateDict[@"pc"] mutableCopy];
					pcd[@"matchesCrashFrame"] = @1;
					stateDict[@"pc"] = pcd;
					stateDict[@"far"] = @{ @"value": @((uint64_t)code[1]) };
				}
				td[@"threadState"] = stateDict;
				td[@"frames"] = backtrace_for_thread(task, &ts, usedImages);
			}
			else
			{
				td[@"frames"] = @[];
			}
			[threadsArray addObject:td];
		}
			
		PEProcess *process = [[PEProcessManager shared] processForProcessIdentifier:pid];
		
		/* codes string */
		NSMutableString *codesString = [[NSMutableString alloc] init];
		for(mach_msg_type_number_t i = 0; i < code_count; i++)
		{
			if(i != 0)
			{
				[codesString appendFormat:@", "];
			}
			[codesString appendFormat:@"0x%016llx", (uint64_t)code[i]];
		}
		
		NSMutableArray *rawCodes = [NSMutableArray array];
		for(mach_msg_type_number_t i = 0; i < code_count; i++)
		{
			[rawCodes addObject:@((uint64_t)code[i])];
		}
		
		#pragma mark - header creation
		
		NSMutableDictionary *header = [NSMutableDictionary dictionary];
		if(process.applicationObject && !process.applicationObject.localizedName.isEmpty)
		{
			header[@"app_name"] = process.applicationObject.localizedName;
		}
		header[@"timestamp"] = make_timestamp([NSDate now]);
		if(process.applicationObject && !process.applicationObject.bundleVersion.isEmpty)
		{
			header[@"app_version"] = process.applicationObject.bundleVersion;
		}
		// header[@"slice_uuid"] = /* help me? */
		// header[@"build_version"] = /* add the field please to LDEApplicationObject */
		if(process.applicationObject && !process.applicationObject.bundleIdentifier.isEmpty)
		{
			header[@"bundleID"] = process.applicationObject.bundleIdentifier;
		}
		header[@"share_with_app_devs"] = @(0);	/* we don't share user data */
		header[@"is_first_party"] = @(0);		/* has to be implemented */
		header[@"bug_type"] = @"309";			/* it must be 309 */
		
		uint32_t ksurface_version = ksurface_kext_info.dependencies[1].min_version;
		
		NSString *incidentID = [[NSUUID UUID] UUIDString];
		
		header[@"platform"] = @(2);	/* always 2 on iOS */
		header[@"incident_id"] = incidentID;
		header[@"bug_type"] = @"309";
		NSProcessInfo *pi = [NSProcessInfo processInfo];
		NSString *marketing = pi.operatingSystemVersionString;
		NSDictionary *sv = [NSDictionary dictionaryWithContentsOfFile:@"/System/Library/CoreServices/SystemVersion.plist"];
		NSString *build = sv[@"ProductBuildVersion"];
		NSString *rt = sv[@"ReleaseType"];
		header[@"os_version"] = [NSString stringWithFormat:@"iPhone OS %@ (%@) + ksurface %u.%u.%u (3rd party kext's installed)", [[UIDevice currentDevice] systemVersion], build ?: @"?", KMOD_VERSION_MAJOR(ksurface_version), KMOD_VERSION_MINOR(ksurface_version), KMOD_VERSION_PATCH(ksurface_version)];
		header[@"roots_installed"] = @(0);
		header[@"name"] = [NSString stringWithCString:proc->bsd.kp_proc.p_comm encoding:NSUTF8StringEncoding];
		
		#pragma mark - payload creation
		
		/* we need the uptime */
		struct timespec now;
		clock_gettime(CLOCK_MONOTONIC, &now);
		uint64_t up = (uint64_t)(now.tv_sec - g_process_start_time.tv_sec);
		
		/* we need process role */
		NSString *procRole = @"Unspecified";
		task_category_policy_data_t cat;
		mach_msg_type_number_t count = TASK_CATEGORY_POLICY_COUNT;
		boolean_t get_default = FALSE;
		kern_return_t kr = task_policy_get(task, TASK_CATEGORY_POLICY, (task_policy_t)&cat, &count, &get_default);
		if(kr == KERN_SUCCESS)
		{
			switch(cat.role)
			{
				case TASK_FOREGROUND_APPLICATION:
					procRole = @"Foreground";
					break;
				case TASK_BACKGROUND_APPLICATION:
					procRole = @"Background";
					break;
				case TASK_UNSPECIFIED:
				default:
					break;
			}
		}
		
		NSString *idfv = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
			
		/* need battery status */
		UIDevice *dev = [UIDevice currentDevice];
		dev.batteryMonitoringEnabled = YES;
		UIDeviceBatteryState state = dev.batteryState;
		
		NSString *chargeMode;
		BOOL externalConnected;
		switch(state)
		{
			case UIDeviceBatteryStateCharging:
				chargeMode = @"chargingWired"; externalConnected = YES;
				break;
			case UIDeviceBatteryStateFull:
				chargeMode = @"full"; externalConnected = YES;
				break;
			case UIDeviceBatteryStateUnplugged:
				chargeMode = @"discharging"; externalConnected = NO;
				break;
			default:
				chargeMode = @"unknown"; externalConnected = NO;
				break;
		}
		
		/* payload */
		NSMutableDictionary *payload = [NSMutableDictionary dictionary];
		[payload addEntriesFromDictionary:@{
			@"uptime": @(up),
			@"procRole": procRole,
			//@"version"
			@"userID": @(proc_geteuid(proc)),
			//@"deployVersion
			@"modelCode": model_code(),
			//@"coalitionID"
			@"osVersion": @{
				@"isEmbedded": @(YES),
				@"train": [NSString stringWithFormat:@"iPhone OS %@ + ksurface %u.%u.%u (3rd party kext's installed)", [[UIDevice currentDevice] systemVersion], KMOD_VERSION_MAJOR(ksurface_version), KMOD_VERSION_MINOR(ksurface_version), KMOD_VERSION_PATCH(ksurface_version)],
				@"releaseType": rt ?: @"?",
				@"build": build ?: @"?",
			},
			@"codeSigningMonitor": @(2),
			@"incident": incidentID,
			@"pid": @(pid),
			@"translated": @(NO),	/* Duy Tran Arm32 is dead! */
			@"cpuType": @"ARM-64",
			//@"procLaunch":
			//@"procStartAbsTime":
			//@"procExitAbsTime":
			@"procName": @(proc->bsd.kp_proc.p_comm),
			@"procPath": @(proc->nyx.identity->path),
		}];
		
		/* byndle info print */
		if(process.applicationObject)
		{
			NSBundle *bundle = [NSBundle bundleWithPath:process.applicationObject.bundlePath];
			if(bundle != nil)
			{
				[payload addEntriesFromDictionary:@{
					@"bundleInfo": @{ @"CFBundleShortVersionString": bundle.infoDictionary[@"CFBundleShortVersionString"] ?: @"", @"CFBundleVersion": bundle.infoDictionary[@"CFBundleVersion"] ?: @"", @"CFBundleIdentifier": bundle.infoDictionary[@"CFBundleIdentifier"] ?: @"" },
				}];
			}
		}
		
		[payload addEntriesFromDictionary:@{
			@"storeInfo": @{ @"deviceIdentifierForVendor": idfv, @"thirdParty": @(YES) },
		}];
		
		ksurface_proc_t *parent;
		kr = proc_parent_for_proc(proc, &parent);
		if(kr == KERN_SUCCESS)
		{
			kvo_rdlock(parent);
			[payload addEntriesFromDictionary:@{
				@"parentProc": @(parent->bsd.kp_proc.p_comm),
				@"parentPid": @(proc_getpid(parent)),
				@"coalitionName": (process.applicationObject) ? (process.applicationObject.bundleIdentifier?: @"") : @"",
			}];
			kvo_unlock(parent);
			kvo_release(parent);
		}
		
		[payload addEntriesFromDictionary:@{
			@"crashReporterKey": crash_reporter_key(),
			@"chargingStatus": @{ @"chargingMode": chargeMode, @"externalSourceConnected": @(externalConnected) },
			@"developerMode": @(1),
			@"bootProgressRegister": @"0x0",
			@"wasUnlockedSinceBoot": @(1),	/* are you rn in Nyxian? */
			@"isLocked": @(0),
			@"throttleTimeout": @(0),
			@"codeSigningID": (process.applicationObject) ? (process.applicationObject.bundleIdentifier?: @"") : @"",
			@"codeSigningTeamID": @"",
			@"codeSigningFlags": @(570434309),	/* this is XNUs shit */
			@"codeSigningValidationCategory": @(3),
			@"codeSigningTrustLevel": @(4),
			@"codeSigningAuxiliaryInfo": @(0),
		}];
		
		/* the instruction byte stream */
		NSString *beforePC = @"", *atPC = @"";
		{
			arm_thread_state64_t threadState;
			mach_msg_type_number_t threadCount = ARM_THREAD_STATE64_COUNT;
			kr = thread_get_state(thread, ARM_THREAD_STATE64, (thread_state_t)&threadState, &threadCount);
			if(kr != KERN_SUCCESS)
			{
				klog_log("org.emexlabs.CrashReporter", "failed to get thread state of guest: %s", mach_error_string(kr));
				goto get_tf_out;
			}
			
			uint64_t pc = arm_thread_state64_get_pc(threadState);
			
			const size_t before = 16;
			const size_t after = 16;
			
			uint8_t buf_before[before], buf_after[after];
			vm_size_t got = 0;
			
			if(vm_read_overwrite(task, pc - before, before, (vm_address_t)buf_before, &got) == KERN_SUCCESS && got == before)
			{
				beforePC = [[NSData dataWithBytes:buf_before length:before] base64EncodedStringWithOptions:0];
			}
			
			got = 0;
			if(vm_read_overwrite(task, pc, after, (vm_address_t)buf_after, &got) == KERN_SUCCESS && got == after)
			{
				atPC = [[NSData dataWithBytes:buf_after length:after] base64EncodedStringWithOptions:0];
			}
		}
	get_tf_out:
		
		[payload addEntriesFromDictionary:@{
			@"instructionByteStream": @{ @"beforePC": beforePC, @"atPC": atPC },
			@"bootSessionUUID": bootSessionUUID.UUIDString,
			@"exception": @{ @"codes": codesString, @"rawCodes": rawCodes, @"type": @(exc_type_name(exc_type)), @"signal":  @(exc_signal_name(exc_type, code[0])) },
			@"termination": @"",	/* can be pulled through PEProcess using it's FrontBoard techniques ik it, cause it gives us the RunningBoard termination reason */
			@"faultingThread": @(faulting_index),
			@"threads": @"__THREADS_PLACEHOLDER__",
		}];
		
		payload[@"captureTime"] = make_timestamp([NSDate now]);
		payload[@"usedImages"] = usedImages;
		payload[@"sharedCache"] = sharedCache;
		payload[@"vmSummary"] = vm_summary_for_task(task);
		//payload[@"logWritingSignature"] /* don't know what that is yet */
		payload[@"bug_type"] = @"309";
		payload[@"roots_installed"] = @(0);
		payload[@"trmStatus"] = @(2048); /*idk just hardcode this shit*/
		payload[@"sandboxProfileName"] = @"container";
		payload[@"spawnFlags"] = @(17420); /* shall be identical */
		
		/* this is missing yet */
		//payload[@"voucherInfos"]   "voucherInfos" : [{"originatorName":"Nyxian","proximateName":"Nyxian","thread_id":1245401},{"originatorName":"Nyxian","proximateName":"Nyxian","thread_id":1245419},{"originatorName":"Nyxian","proximateName":"Nyxian","thread_id":1245422},{"originatorName":"Nyxian","proximateName":"Nyxian","thread_id":1245436},{"originatorName":"Nyxian","proximateName":"audiomxd","thread_id":1245507}],
		
		/*
  "trialInfo" : {
  "rollouts" : [
    {
      "rolloutId" : "652eff3d1bce5442b8d753c9",
      "factorPackIds" : [
        "652eff982c02f032beae83f4"
      ],
      "deploymentId" : 250000005
    },
    {
      "rolloutId" : "6a51666818a3ab339a33e93c",
      "factorPackIds" : [
        "6a51685d654ed37dfa0a5f30",
        "6a51689f18a3ab339a33e93f",
        "6a5168260d9d987af019189b"
      ],
      "deploymentId" : 1
    }
  ],
  "experiments" : [

  ]
}
}

		*/
		payload[@"version"] = @(2);
		
		NSData *headerData  = [NSJSONSerialization dataWithJSONObject:header options:0 error:nil];
		
		NSData *prettyData = [NSJSONSerialization dataWithJSONObject:payload options:NSJSONWritingPrettyPrinted | NSJSONWritingSortedKeys error:nil];
		NSMutableString *out = [[NSMutableString alloc] initWithData:prettyData encoding:NSUTF8StringEncoding];
		
		NSData *threadsData = [NSJSONSerialization dataWithJSONObject:threadsArray options:0 error:nil];
		NSString *threadsJSON = [[NSString alloc] initWithData:threadsData encoding:NSUTF8StringEncoding];
		
		[out replaceOccurrencesOfString:@"\"__THREADS_PLACEHOLDER__\"" withString:threadsJSON options:0 range:NSMakeRange(0, out.length)];
		
		NSData *finalPayload = [out dataUsingEncoding:NSUTF8StringEncoding];
		
		write_all(fd, headerData.bytes, headerData.length);
		write_all(fd, "\n", 1);
		write_all(fd, finalPayload.bytes, finalPayload.length);
	}
	
	close(fd);
	
	CFRelease(path);
	
	kvo_unlock(&proc);
	kvo_release(proc);
}
